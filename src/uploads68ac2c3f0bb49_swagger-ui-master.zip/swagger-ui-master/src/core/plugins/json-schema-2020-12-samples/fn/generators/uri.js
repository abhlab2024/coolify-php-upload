/**
 * @prettier
 */
const uriGenerator = () => "https://example.com/"

export default uriGenerator
